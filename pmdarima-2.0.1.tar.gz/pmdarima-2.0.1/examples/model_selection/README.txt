.. _model_selection_examples:

Cross-validation examples
-------------------------

Examples of how to use the :mod:`pmdarima.model_selection` module to fit
timeseries models in a cross-validated fashion.

.. raw:: html

   <br/>
